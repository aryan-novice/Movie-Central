
public class global {
    
    public static String name="";
    public static  String email="";
    public static String mobile="";
    public static String address="";
    public static String photo="";

}
