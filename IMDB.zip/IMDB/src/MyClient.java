
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import java.io.File;

import java.sql.*;

public class MyClient 
{
    public static String api = "50b6ad672f35ee5f20d7bd3cd0433671";

    public static String signup(String name, String email, String password, String mobile, String address, File f1) {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from user where user_email='" + email + "'");
            if (rs.next()) {
                ans = ans + "fail";

            } else {
                String photo = SaveFile.saveFile(f1);
                rs.moveToInsertRow();
                rs.updateString("name", name);
                rs.updateString("email", email);
                rs.updateString("password", password);
                rs.updateString("mobile", mobile);
                rs.updateString("address", address);
                rs.updateString("photo", photo);
                rs.insertRow();
                ans = ans + "success";

            }
            return ans;
        } catch (Exception ex) {
            return ex.toString();
        }

    }

    public static String login(String email, String password) {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from user where email='" + email + "' and password='" + password + "'");
            if (rs.next()) {
                ans = ans + "success";

                String name = rs.getString("name");
                String Email = rs.getString("email");
                String mobile = rs.getString("mobile");
                String address = rs.getString("address");
                String photo = rs.getString("photo");
                global.name = name;
                global.email = email;
                global.address = address;
                global.mobile = mobile;
                global.photo = photo;

            } else {
                ans = ans + "fail";
            }
            return ans;
        } catch (Exception ex) {
            return ex.toString();
        }
    }

    public static String upcoming() {
        try {
            HttpResponse<String> res = Unirest.get("https://api.themoviedb.org/3/movie/upcoming?api_key=" + api).asString();
            if (res.getStatus() == 200) 
            {
                return res.getBody();
            } 
            else 
            {
                return "server error";
            }
        } catch (Exception ex) {
            return ex.toString();
        }

    }

    public static String update_profile(String name, String mobile, String address, File f) {
        String ans = "";
        try {

            String photo = SaveFile.saveFile(f);
            ResultSet rs = DBLoader.executeSQL("select * from user where email='" + global.email + "'");
            if (rs.next()) {
                rs.updateString("name", name);
                rs.updateString("mobile", mobile);
                rs.updateString("address", address);
                rs.updateString("photo", photo);
                rs.updateRow();
                ans = ans + "success";

            } else {
                ans = ans + "fail";
            }
            return ans;
        } catch (Exception ex) {
            return ex.toString();
        }
    }

    public static String change_pass(String old, String new_pass) {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from user where email='" + global.email + "' and password='" + old + "'");
            if (rs.next()) {
                rs.updateString("password", new_pass);
                rs.updateRow();
                ans = ans + "success";
            } else {
                ans = ans + "fail";

            }
            return ans;

        } catch (Exception ex) {
            return ex.toString();
        }

    }

    public static String fav_movie(int id) {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from fav_movie where user_email='" + global.email + "' and id=" + id);
            if (rs.next()) {
                ans = ans + "success";
            } else {
                ans = ans + "fail";
            }
            return ans;
        } catch (Exception ex) {
            return ex.toString();
        }
    }

    public static String add_fav_movie(int id) {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from fav_movie where user_email='" + global.email + "' and id=" + id);
            if (rs.next()) {
                rs.deleteRow();
                ans = ans + "remove";
            } else {
                rs.moveToInsertRow();
                rs.updateString("user_email", global.email);
                rs.updateInt("id", id);
                rs.insertRow();
                ans = ans + "add";
            }
            return ans;
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public static String Toprated() {
        try {
            HttpResponse<String> res = Unirest.get("https://api.themoviedb.org/3/movie/top_rated?api_key=" + api).asString();
            if (res.getStatus() == 200) {
                return res.getBody();
            } else {
                return "server error";
            }
        } catch (Exception ex) {
            return ex.toString();
        }

    }

    public static String searchMovie(String movie) {
        try {
            HttpResponse<String> res = Unirest.get("https://api.themoviedb.org/3/search/movie?query=" + movie + "&include_adult=false&language=en-US&page=1&api_key=" + api).asString();
            if (res.getStatus() == 200) {
                return res.getBody();
            } else {
                return "server error";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public static String searchActor(String actor) {
        try {
            HttpResponse<String> res = Unirest.get("https://api.themoviedb.org/3/search/person?query=" + actor + "&include_adult=false&language=en-US&page=1&api_key=" + api).asString();
            if (res.getStatus() == 200) {
                return res.getBody();
            } else {
                return "server error";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public static String searchTV(String tv) {
        try {
            HttpResponse<String> res = Unirest.get("https://api.themoviedb.org/3/search/tv?query=" + tv + "&include_adult=false&language=en-US&page=1&api_key=" + api).asString();
            if (res.getStatus() == 200) {
                return res.getBody();
            } else {
                return "server error";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public static String searchCompany(String company) {
        try {
            HttpResponse<String> res = Unirest.get("https://api.themoviedb.org/3/search/company?api_key=" + api + "&query=" + company + "&page=1").asString();
            if (res.getStatus() == 200) {
                return res.getBody();
            } else {
                return "server error";
            }
        } catch (Exception ex) {
            ex.printStackTrace();;
            return ex.toString();
        }
    }

    
    public static String Multi(String multi) {
        try {
            HttpResponse<String> res = Unirest.get("https://api.themoviedb.org/3/search/multi?api_key=" + api + "&language=en-US&query=" + multi + "&page=1&include_adult=false")
                    .asString();
            if (res.getStatus() == 200) {
                return res.getBody();

            } else {
                return "server error";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public static String fetch_fav() {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from fav_movie where user_email='" + global.email + "'");
            while (rs.next()) {
                int id = rs.getInt("id");
                ans = ans + id + "$";
            }
            return ans;
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public static String fetch_fav_Tv() {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from fav_tv where user_email='" + global.email + "'");
            while (rs.next()) {
                int id = rs.getInt("id");
                ans = ans + id + "$";
            }
            return ans;
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public static String add_fav_tv(int id) {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from fav_tv where user_email='" + global.email + "' and id=" + id);
            if (rs.next()) {
                rs.deleteRow();
                ans = ans + "remove";
            } else {
                rs.moveToInsertRow();
                rs.updateString("user_email", global.email);
                rs.updateInt("id", id);
                rs.insertRow();
                ans = ans + "add";
            }
            return ans;
        } catch (Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }

    }

    public static String fav_tv(int id) {
        String ans = "";
        try {
            ResultSet rs = DBLoader.executeSQL("select * from fav_tv where user_email='" + global.email + "' and id=" + id);
            if (rs.next()) {
                ans = ans + "success";
            } else {
                ans = ans + "fail";
            }
            return ans;
        } catch (Exception ex) {
            return ex.toString();
        }
    }
}
