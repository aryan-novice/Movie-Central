

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import org.json.JSONArray;
import org.json.JSONObject;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author macbookair
 */
public class TopRated extends javax.swing.JFrame {

    /**
     * Creates new form TopRated
     */
    public TopRated() {
        initComponents();
        Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
        int h=(int)d.getHeight();
        int w=(int)d.getWidth();
        setSize(w, h);
        setVisible(true);
        getContentPane().setBackground(Color.black);
         TopRated();
        
        
    }

    void TopRated()
    {
    String ans=MyClient.Toprated();
        System.out.println(ans);
       
        jPanel1.removeAll();
        JSONObject mainobj=new JSONObject(ans);
        System.out.println(ans);
        JSONArray arr=mainobj.getJSONArray("results");
        int x=10;
        int y=10;
        for(int i=0;i<arr.length();i++)
        {
          JSONObject obj=(JSONObject)(arr.get(i));
           
          
           TopTrending top=new TopTrending();
           
           if(obj.has("original_title"))
           {
            String name=obj.get("original_title").toString();
            top.movie.setText(name);
              
           }
           if(obj.has("title"))
           {
            String name=obj.get("title").toString();
            top.movie.setText(name);
           }
           if(obj.has("overview"))
           {
            String overviewString=obj.get("overview").toString();
             String overview = "";
            
            String[] n = overviewString.split("(?<=\\G.{" + 39 + "})");
                    for (String string : n) {
                        overview += string + " " + "\n" + " ";
                    }
             top.description.setText(overview);
           }
           
           int id=(int)obj.get("id");
           String res=MyClient.fav_movie(id);
           if(res.equals("success")){
//           top.jButton1.setText("Added");
           ImageIcon ic=new ImageIcon("src/myuploads/heart (1).png");
           Image img=ic.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
           ImageIcon im=new ImageIcon(img);
           top.jButton1.setIcon(im);
           
           }
           else
           {
            ImageIcon ic=new ImageIcon("src/myuploads/heart.png");
           Image img=ic.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
           ImageIcon im=new ImageIcon(img);
           top.jButton1.setIcon(im);
           
           }
           
           top.jButton1.addActionListener(new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent e) {
                  String ans=MyClient.add_fav_movie(id);
                  if(ans.equals("remove"))
                  {
//                      top.jButton1.setText("Add");
                        ImageIcon ic=new ImageIcon("src/myuploads/heart.png");
           Image img=ic.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
           ImageIcon im=new ImageIcon(img);
           top.jButton1.setIcon(im);
                  }
                  else
                  {
//                  top.jButton1.setText("Added");
                    ImageIcon ic=new ImageIcon("src/myuploads/heart (1).png");
            Image img=ic.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
             ImageIcon im=new ImageIcon(img);
            top.jButton1.setIcon(im);
                  }
                  
              }
           });
           
           
           
           if(obj.has("release_date"))
           {
        String release_date=obj.get("release_date").toString();
        top.date.setText(release_date);
           }
           
           if(obj.has("poster_path"))
              
           {
               String photo=obj.get("poster_path").toString();
               System.out.println(photo);
               try{
//               ImageIcon io=new ImageIcon(new URL("https://image.tmdb.org/t/p/w200"+photo));
//               Image img=io.getImage().getScaledInstance(top.poster.getWidth(), top.poster.getHeight(),Image.SCALE_SMOOTH);
//               ImageIcon im=new ImageIcon(img);
            BufferedImage bi = ImageIO.read(new URL("https://image.tmdb.org/t/p/w200"+photo));

                bi = scale(bi, top.poster.getWidth(), top.poster.getHeight());
               top.poster.setIcon(new ImageIcon(bi));
               }
               catch(Exception ex)
               {
               ex.printStackTrace();
               }
                       
            }
            
          top.setBounds(x, y   , 307, 395);
          top.setVisible(true);
          if(x<961){
          x=x+317;
          
          }
          else
          {
          y=y+405;
          x=10;
          }
          jPanel1.add(top);
          jPanel1.repaint();
          jPanel1.revalidate();
          top.repaint();
          top.revalidate();
          
          
        }
        jPanel1.setPreferredSize(new Dimension(1278,y+100));
   
    
    
    }
     public static BufferedImage scale(BufferedImage src, int w, int h) {
        BufferedImage img
                = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        int x, y;
        int ww = src.getWidth();
        int hh = src.getHeight();
        int[] ys = new int[h];
        for (y = 0; y < h; y++) {
            ys[y] = y * hh / h;
        }
        for (x = 0; x < w; x++) {
            int newX = x * ww / w;
            for (y = 0; y < h; y++) {
                int col = src.getRGB(newX, ys[y]);
                img.setRGB(x, y, col);
            }
        }
        return img;
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 3, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Top Rated Movies");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(580, 20, 440, 50);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);
        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(50, 100, 1330, 730);

        jButton1.setFont(new java.awt.Font("Helvetica Neue", 3, 14)); // NOI18N
        jButton1.setText("Home");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(20, 10, 100, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        user_home us=new user_home();
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TopRated.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TopRated.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TopRated.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TopRated.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TopRated().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
